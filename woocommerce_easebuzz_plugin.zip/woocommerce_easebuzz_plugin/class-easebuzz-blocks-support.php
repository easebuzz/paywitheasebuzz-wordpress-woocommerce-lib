<?php

/**
 * Easebuzz Gateway - Blocks payment method integration.
 *
 * Registers the gateway with the WooCommerce Cart & Checkout blocks by
 * extending AbstractPaymentMethodType. Reuses the existing gateway settings
 * (title/description) so there is no duplicated configuration.
 */

if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class WC_Easebuzz_Blocks_Support extends AbstractPaymentMethodType
{
    /**
     * Payment method name/id. Must match the gateway id and the JS name.
     *
     * @var string
     */
    protected $name = 'payeasebuzz';

    /**
     * Gateway settings pulled from the shared WooCommerce option.
     *
     * @var array
     */
    private $gateway_settings = array();

    /**
     * Initialize settings from the same option key the gateway uses.
     */
    public function initialize()
    {
        $this->settings = get_option(EASEBUZZ_SETTINGS_KEY, array());
        $this->gateway_settings = $this->settings;
    }

    /**
     * Whether the payment method is active/enabled.
     *
     * @return bool
     */
    public function is_active()
    {
        return !empty($this->gateway_settings['enabled']) && $this->gateway_settings['enabled'] === 'yes';
    }

    /**
     * Register and return the script handles for the block integration.
     *
     * @return array
     */
    public function get_payment_method_script_handles()
    {
        $handle = 'wc-easebuzz-blocks';
        $script_path = 'assets/js/blocks.js';
        $script_url = EASEBUZZ_PLUGIN_URL . $script_path;
        $script_file = EASEBUZZ_PLUGIN_DIR . $script_path;

        wp_register_script(
            $handle,
            $script_url,
            array(
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
                'wc-blocks-registry',
                'wc-settings',
            ),
            file_exists($script_file) ? (string) filemtime($script_file) : EASEBUZZ_PLUGIN_VERSION,
            true
        );

        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations($handle, 'woo_payeasebuzz');
        }

        return array($handle);
    }

    /**
     * Data passed to the front-end script (via wcSettings 'payeasebuzz_data').
     *
     * @return array
     */
    public function get_payment_method_data()
    {
        return array(
            'title'       => isset($this->gateway_settings['title']) ? $this->gateway_settings['title'] : __('Easebuzz Payment Gateway', 'woo_payeasebuzz'),
            'description' => isset($this->gateway_settings['description']) ? $this->gateway_settings['description'] : '',
            'supports'    => $this->get_easebuzz_supports(),
        );
    }

    /**
     * Supported features, derived from the registered gateway instance.
     *
     * @return array
     */
    private function get_easebuzz_supports()
    {
        $gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();

        if (isset($gateways[$this->name]) && is_array($gateways[$this->name]->supports)) {
            return array_values($gateways[$this->name]->supports);
        }

        return array('products');
    }
}
