<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('EASEBUZZ_SETTINGS_KEY')) {
    define('EASEBUZZ_SETTINGS_KEY', 'woocommerce_payeasebuzz_settings');
}

/**
 * Initiate payment page request to Easebuzz.
 *
 * @param array  $params Payment parameters.
 * @param string $salt   Merchant salt.
 * @param string $env    Environment (test|prod).
 * @return array Response with status and data.
 */
function easepay_page($params, $salt, $env = 'test')
{
    if (!is_array($params)) {
        return array('status' => 0, 'data' => 'Payment params must be an array.');
    }

    if (empty($salt)) {
        return array('status' => 0, 'data' => 'Salt is empty.');
    }

    $payment = new Easebuzz_Payment($salt, $env);
    $result  = $payment->initiate($params);

    return $result;
}

/**
 * Format order note from Easebuzz payment response params.
 *
 * @param string $prefix Note prefix (e.g. "Easebuzz payment successful").
 * @param array  $params Response parameters containing easepayid, txnid, bank_ref_num, mode.
 * @return string Formatted order note HTML.
 */
function easebuzz_format_order_note($prefix, $params)
{
    return sprintf(
        '%s<br/>Easebuzz ID: %s<br/>Transaction ID: %s<br/>Bank Ref: %s (%s)',
        $prefix,
        sanitize_text_field($params['easepayid'] ?? ''),
        sanitize_text_field($params['txnid'] ?? ''),
        sanitize_text_field($params['bank_ref_num'] ?? ''),
        sanitize_text_field($params['mode'] ?? '')
    );
}

/**
 * Compute reverse hash for response/webhook verification.
 *
 * @param array  $params Response parameters from Easebuzz.
 * @param string $salt   Merchant salt.
 * @return string Computed SHA-512 hash.
 */
function easebuzz_compute_reverse_hash($params, $salt)
{
    $hash_sequence = 'udf10|udf9|udf8|udf7|udf6|udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid|key';
    $hash_vars     = explode('|', $hash_sequence);

    $hash_string = $salt . '|' . (isset($params['status']) ? $params['status'] : '');
    foreach ($hash_vars as $var) {
        $hash_string .= '|' . (isset($params[$var]) ? $params[$var] : '');
    }

    return strtolower(hash('sha512', $hash_string));
}

/**
 * Handles payment initiation with Easebuzz API.
 */
class Easebuzz_Payment
{
    const SUCCESS = 1;
    const FAILURE = 0;
    const IFRAME  = 'iframe';

    const HASH_SEQUENCE = 'key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10';

    private $url;
    private $salt;

    public function __construct($salt, $env = 'test')
    {
        $this->salt = $salt;
        $this->url  = ($env === 'prod')
            ? 'https://pay.easebuzz.in/'
            : 'https://testpay.easebuzz.in/';
    }

    /**
     * Initiate payment by calling Easebuzz API.
     *
     * @param array $params Payment request parameters.
     * @return array
     */
    public function initiate($params)
    {
        $error = $this->validate_params($params);
        if ($error !== true) {
            return array('status' => self::FAILURE, 'data' => $error);
        }

        $params['hash'] = $this->generate_hash($params);
        $result = $this->api_call($this->url . 'payment/initiateLink', $params);

        if ($result['success'] === false) {
            return array('status' => self::FAILURE, 'data' => $result['error']);
        }

        $access_key = $result['data'];

        // Check if iframe mode is enabled
        $settings = get_option(EASEBUZZ_SETTINGS_KEY, array());
        if (isset($settings['enable_iframe']) && $settings['enable_iframe'] === 'yes') {
            return array(
                'status' => self::IFRAME,
                'data'   => array(
                    'access_key' => $access_key,
                    'key'        => $settings['key_id'] ?? $params['key'],
                ),
            );
        }

        return array(
            'status' => self::SUCCESS,
            'data'   => $this->url . 'pay/' . $access_key,
        );
    }

    /**
     * Generate forward hash for payment initiation.
     */
    private function generate_hash($params)
    {
        $hash_vars   = explode('|', self::HASH_SEQUENCE);
        $hash_string = '';

        foreach ($hash_vars as $var) {
            $hash_string .= isset($params[$var]) ? $params[$var] : '';
            $hash_string .= '|';
        }
        $hash_string .= $this->salt;

        return strtolower(hash('sha512', $hash_string));
    }

    /**
     * Validate mandatory payment parameters.
     */
    private function validate_params($params)
    {
        $required = array('key', 'txnid', 'amount', 'firstname', 'email', 'phone', 'productinfo', 'surl', 'furl');

        foreach ($required as $field) {
            if (empty($params[$field])) {
                return 'Mandatory parameter ' . $field . ' is empty.';
            }
        }

        return true;
    }

    /**
     * Make API call to Easebuzz.
     *
     * @param string $url  API endpoint.
     * @param array  $data POST parameters.
     * @return array
     */
    private function api_call($url, $data)
    {
        $args = array(
            'body'      => $data,
            'timeout'   => 30,
            'sslverify' => true,
            'headers'   => array(
                'User-Agent' => 'WooCommerce-Easebuzz/' . EASEBUZZ_PLUGIN_VERSION,
            ),
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            return array('success' => false, 'error' => $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $decoded = json_decode($body);

        if (!$decoded) {
            return array('success' => false, 'error' => 'Invalid API response.');
        }

        if (isset($decoded->status) && $decoded->status == 1) {
            return array('success' => true, 'data' => $decoded->data);
        }

        $error_msg = isset($decoded->error_desc) ? $decoded->error_desc : 'Payment initiation failed.';
        return array('success' => false, 'error' => $error_msg);
    }
}
