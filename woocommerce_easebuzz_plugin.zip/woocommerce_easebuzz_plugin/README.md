# WooCommerce Easebuzz Payment Gateway Plugin

Integration plugin for [Easebuzz](https://pay.easebuzz.in) payment gateway with WooCommerce.

## Installation

1. Download or clone this repository.
2. Zip the folder (or use the pre-built zip).
3. In WordPress Admin, go to **Plugins → Add New → Upload Plugin**.
4. Upload the zip file and activate the plugin.
5. Navigate to **WooCommerce → Settings → Payments → Easebuzz Gateway**.
6. Enter your **Merchant Key** and **Merchant Salt** (provided by Easebuzz).
7. Select your environment mode (Test/Live).
8. Set Success and Failure redirect pages (recommended: "Checkout" page for both).
9. Save changes.

## Webhook Configuration

The webhook automatically reads the salt from your WooCommerce gateway settings — no manual file editing required.

1. Copy the webhook URL: `https://yourdomain.com/wp-content/plugins/woocommerce_easebuzz_plugin/update_webhook.php`
2. Log in to your Easebuzz Dashboard.
3. Navigate to: **Account Settings → Webhook → Transaction Webhook**.
4. Paste the webhook URL and save.

## Features

- Standard redirect payment flow
- Easecheckout (iframe) payment flow
- Webhook for async order status sync
- Test and Live mode support
- Secure hash verification on all callbacks

## Requirements

- WordPress 5.0+
- WooCommerce 3.0+
- PHP 7.4+
