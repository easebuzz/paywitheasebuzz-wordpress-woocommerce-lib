<?php

/*
    Plugin Name: Easebuzz Gateway
    Plugin URI: https://pay.easebuzz.in/
    Description: Easebuzz Payment Gateway Integration for WooCommerce
    Version: 5.6.0
    Developer: Rajesh Kushwaha
    Author: Team Easebuzz
    Author URI: http://www.easebuzz.in/
    License: GNU General Public License v3.0
    License URI: http://www.gnu.org/licenses/gpl-3.0.html
    WC requires at least: 3.0
    WC tested up to: 8.0
    Requires PHP: 7.4
*/

if (!defined('ABSPATH')) {
    exit;
}

define('EASEBUZZ_PLUGIN_VERSION', '5.6.0');
define('EASEBUZZ_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('EASEBUZZ_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EASEBUZZ_IMG_URL', EASEBUZZ_PLUGIN_URL . 'assets/img/');
define('EASEBUZZ_SETTINGS_KEY', 'woocommerce_payeasebuzz_settings');

add_action('plugins_loaded', 'woocommerce_gateway_payeasebuzz_init', 0);

function woocommerce_gateway_payeasebuzz_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Easebuzz_Gateway extends WC_Payment_Gateway
    {
        private $redirect_page;
        private $redirect_fail_page;
        private $key_id;
        private $key_secret;
        private $enable_iframe;
        private $msg;

        public function __construct()
        {
            $this->id                 = 'payeasebuzz';
            $this->method_title       = 'Easebuzz Gateway';
            $this->method_description = 'Pay with Easebuzz - Redefining Payments';
            $this->has_fields         = false;

            $this->init_form_fields();
            $this->init_settings();

            $this->title              = $this->get_option('title');
            $this->description        = $this->get_option('description');
            $this->key_id             = $this->get_option('key_id');
            $this->key_secret         = $this->get_option('key_secret');
            $this->redirect_page      = $this->get_option('redirect_page');
            $this->redirect_fail_page = $this->get_option('redirect_fail_page');
            $this->enable_iframe      = $this->get_option('enable_iframe');

            $show_logo = $this->get_option('show_logo');
            if ($show_logo !== 'no') {
                $this->icon = EASEBUZZ_IMG_URL . $show_logo . '.png';
            }

            $this->msg = array('message' => '', 'class' => '');

            // Hooks
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'check_payeasebuzz_response'));
            add_action('woocommerce_receipt_payeasebuzz', array($this, 'receipt_page'));
        }

        /**
         * Admin form fields configuration.
         */
        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title'       => __('Enable/Disable:', 'woo_payeasebuzz'),
                    'type'        => 'checkbox',
                    'label'       => __('Enable Easebuzz', 'woo_payeasebuzz'),
                    'default'     => 'no',
                    'description' => __('Show in the Payment List as a payment option', 'woo_payeasebuzz'),
                ),
                'title' => array(
                    'title'       => __('Title:', 'woo_payeasebuzz'),
                    'type'        => 'text',
                    'default'     => __('Easebuzz Payment Gateway', 'woo_payeasebuzz'),
                    'description' => __('This controls the title which the user sees during checkout.', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => __('Description:', 'woo_payeasebuzz'),
                    'type'        => 'textarea',
                    'default'     => __('Pay securely by Credit or Debit card or internet banking through Easebuzz.', 'woo_payeasebuzz'),
                    'description' => __('This controls the description which the user sees during checkout.', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'key_id' => array(
                    'title'       => __('Merchant KEY:', 'woo_payeasebuzz'),
                    'type'        => 'text',
                    'placeholder' => __('Enter The Merchant Key', 'woo_payeasebuzz'),
                    'description' => __('Given to Merchant by Easebuzz', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'key_secret' => array(
                    'title'       => __('Merchant SALT:', 'woo_payeasebuzz'),
                    'type'        => 'password',
                    'placeholder' => __('Enter The Merchant Salt', 'woo_payeasebuzz'),
                    'description' => __('Given to Merchant by Easebuzz', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'test_mode' => array(
                    'title'       => __('Mode:', 'woo_payeasebuzz'),
                    'type'        => 'select',
                    'options'     => array('test' => 'Test Mode', 'prod' => 'Live Mode'),
                    'default'     => 'test',
                    'description' => __('Mode of Easebuzz activities', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'redirect_page' => array(
                    'title'       => __('Success URL', 'woo_payeasebuzz'),
                    'type'        => 'select',
                    'options'     => $this->easebuzz_get_pages('Select Page'),
                    'description' => __('URL of success page', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'redirect_fail_page' => array(
                    'title'       => __('Failure URL', 'woo_payeasebuzz'),
                    'type'        => 'select',
                    'options'     => $this->easebuzz_get_pages('Select Page'),
                    'description' => __('URL of failure page', 'woo_payeasebuzz'),
                    'desc_tip'    => true,
                ),
                'show_logo' => array(
                    'title'       => __('Show Logo:', 'woo_payeasebuzz'),
                    'type'        => 'select',
                    'options'     => array('no' => 'No Logo', 'pay01' => 'Easebuzz - Icon', 'pay02' => 'Easebuzz - Logo'),
                    'default'     => 'no',
                    'description' => __('<strong>Easebuzz logo:</strong> | Icon: <img src="' . EASEBUZZ_IMG_URL . 'pay01.png" height="24px" /> | Logo: <img src="' . EASEBUZZ_IMG_URL . 'pay02.png" height="24px" />', 'woo_payeasebuzz'),
                    'desc_tip'    => false,
                ),
                'enable_iframe' => array(
                    'title'       => __('Enable/Disable:', 'woo_payeasebuzz'),
                    'type'        => 'checkbox',
                    'label'       => __('Enable Easecheckout (iframe)', 'woo_payeasebuzz'),
                    'default'     => 'no',
                    'description' => __('Easecheckout option', 'woo_payeasebuzz'),
                ),
            );
        }

        /**
         * Get WordPress pages for redirect URL dropdown.
         */
        private function easebuzz_get_pages($title = false, $indent = true)
        {
            $wp_pages  = get_pages('sort_column=menu_order');
            $page_list = array();

            if ($title) {
                $page_list[] = $title;
            }

            foreach ($wp_pages as $page) {
                $prefix = '';
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix    .= ' - ';
                        $next_page  = get_post($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                $page_list[$page->ID] = $prefix . $page->post_title;
            }

            return $page_list;
        }

        /**
         * Admin panel options.
         */
        public function admin_options()
        {
            echo '<h3>' . esc_html__('Easebuzz', 'woo_payeasebuzz') . '</h3>';
            echo '<p><small><strong>' . esc_html__('Confirm your Mode: Is it LIVE or TEST.', 'woo_payeasebuzz') . '</strong></small></p>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }

        /**
         * Show description on checkout.
         */
        public function payment_fields()
        {
            if ($this->description) {
                echo wpautop(wptexturize(esc_html($this->description)));
            }
        }

        /**
         * Receipt page - triggers payment form generation.
         */
        public function receipt_page($order)
        {
            echo '<div id="ebz-checkout-btn"></div>';
            echo $this->generate_payeasebuzz_form($order);
        }

        /**
         * Build redirect URL with WC API callback.
         */
        private function get_redirect_url($page_id)
        {
            if (empty($page_id) || $page_id == 0) {
                $url = get_site_url() . "/";
            } else {
                $url = get_permalink($page_id);
            }
            return add_query_arg('wc-api', get_class($this), $url);
        }

        /**
         * Generate unique transaction ID.
         */
        private function generate_txnid($order_id)
        {
            return $order_id . '-' . wp_generate_password(12, false);
        }

        /**
         * Generate payment form / initiate payment with Easebuzz.
         */
        private function generate_payeasebuzz_form($order_id)
        {
            $order = wc_get_order($order_id);
            if (!$order) {
                return $this->render_error_script(__('Invalid order.', 'woo_payeasebuzz'));
            }

            $redirect_url      = $this->get_redirect_url($this->redirect_page);
            $redirect_fail_url = $this->get_redirect_url($this->redirect_fail_page);
            $env               = ($this->get_option('test_mode') === 'prod') ? 'prod' : 'test';
            $salt              = trim($this->key_secret);

            include_once EASEBUZZ_PLUGIN_DIR . 'easepay-lib.php';

            $payment_request_parameter = array(
                'key'         => trim($this->key_id),
                'txnid'       => $this->generate_txnid($order_id),
                'amount'      => trim($order->get_total()),
                'firstname'   => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                'email'       => trim($order->get_billing_email()),
                'phone'       => trim($order->get_billing_phone()),
                'udf1'        => trim($order_id),
                'udf2'        => trim($order->get_order_key()),
                'productinfo' => trim("Order $order_id"),
                'surl'        => trim($redirect_url),
                'furl'        => trim($redirect_fail_url),
            );

            $response = easepay_page($payment_request_parameter, $salt, $env);

            if ($response['status'] === 1) {
                // Standard redirect flow
                wp_redirect($response['data']);
                exit;
            } elseif ($response['status'] === 'iframe') {
                // Easecheckout iframe flow
                return $this->render_iframe_checkout($response['data'], $env);
            } else {
                // Error - log the details but show generic message to user
                $error_msg = isset($response['data']) ? $response['data'] : 'Unknown error';
                $this->log('Payment initiation failed: ' . $error_msg);
                return $this->render_error_script(__('Unable to initiate payment. Please try again or contact support.', 'woo_payeasebuzz'));
            }
        }

        /**
         * Render iframe/easecheckout JS.
         */
        private function render_iframe_checkout($data, $env)
        {
            $key        = esc_js($data['key']);
            $access_key = esc_js($data['access_key']);
            $ajaxurl    = esc_url(admin_url('admin-ajax.php'));
            $nonce      = wp_create_nonce('easebuzz_iframe_payment');

            return "
            <style>
                #ebz-loading {
                    background: url('" . esc_url(EASEBUZZ_IMG_URL . 'pay01.png') . "') no-repeat center center;
                    position: fixed; top: 0; left: 0;
                    height: 100%; width: 100%;
                    z-index: 9999999; background-size: 80px;
                    background-color: rgba(255,255,255,0.8);
                    display: none;
                }
            </style>
            <script src='https://ebz-static.s3.ap-south-1.amazonaws.com/easecheckout/v2.0.0/easebuzz-checkout-v2.min.js'></script>
            <script type='text/javascript'>
                jQuery(function(){
                    jQuery('body').append('<div id=\"ebz-loading\"></div>');
                    var easebuzzCheckout = new EasebuzzCheckout('{$key}', '{$env}');

                    jQuery('#ebz-checkout-btn').on('click', function(e) {
                        var options = {
                            access_key: '{$access_key}',
                            onResponse: function(response_data) {
                                jQuery('#ebz-loading').show();
                                jQuery.ajax({
                                    type: 'post',
                                    data: {
                                        action: 'payment_response_iframe',
                                        response: response_data,
                                        _nonce: '{$nonce}'
                                    },
                                    dataType: 'json',
                                    url: '{$ajaxurl}',
                                    success: function(data) {
                                        var html = '<div style=\"margin-top:20px;padding:15px\">' + (data.message || 'Transaction processed.') + '</div>';
                                        if (jQuery('#ebz-checkout-btn').length) {
                                            jQuery('#ebz-checkout-btn').after(html);
                                        } else if (jQuery('.entry-content').length) {
                                            jQuery('.entry-content').append(html);
                                        } else {
                                            jQuery('.woocommerce').append(html);
                                        }
                                        jQuery('#ebz-loading').hide();
                                    },
                                    error: function() {
                                        var errHtml = '<div style=\"margin-top:20px;padding:15px;color:red\">Something went wrong. Please check your order status or try again.</div>';
                                        if (jQuery('#ebz-checkout-btn').length) {
                                            jQuery('#ebz-checkout-btn').after(errHtml);
                                        } else {
                                            jQuery('.woocommerce').append(errHtml);
                                        }
                                        jQuery('#ebz-loading').hide();
                                    }
                                });
                            },
                            theme: '#123456'
                        };
                        easebuzzCheckout.initiatePayment(options);
                    });
                    jQuery('#ebz-checkout-btn').trigger('click');
                });
            </script>";
        }

        /**
         * Render error message script.
         */
        private function render_error_script($message)
        {
            $message = esc_js($message);
            return "<script type='text/javascript'>
                jQuery(function(){
                    jQuery('body').block({
                        message: '{$message}',
                        overlayCSS: { background: '#fff', opacity: 0.8 },
                        css: {
                            padding: '30px', textAlign: 'center', color: '#666',
                            border: '3px solid #aaa', backgroundColor: '#fff',
                            cursor: 'wait', lineHeight: 'normal',
                            margin: 'auto', width: '320px'
                        }
                    });
                });
            </script>";
        }

        /**
         * Process payment - redirect to receipt page.
         */
        public function process_payment($order_id)
        {
            $order = wc_get_order($order_id);

            return array(
                'result'   => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            );
        }

        /**
         * Compute reverse hash for response verification.
         */
        private function compute_reverse_hash($params)
        {
            include_once EASEBUZZ_PLUGIN_DIR . 'easepay-lib.php';
            return easebuzz_compute_reverse_hash($params, $this->key_secret);
        }

        /**
         * Format order note from payment response.
         */
        private function format_order_note($prefix, $params)
        {
            include_once EASEBUZZ_PLUGIN_DIR . 'easepay-lib.php';
            return easebuzz_format_order_note($prefix, $params);
        }

        /**
         * Handle Easebuzz callback response (surl/furl redirect).
         */
        public function check_payeasebuzz_response()
        {
            if (!isset($_REQUEST['txnid']) || !isset($_REQUEST['easepayid'])) {
                return;
            }

            $order_id = isset($_REQUEST['udf1']) ? absint($_REQUEST['udf1']) : 0;
            if (!$order_id) {
                return;
            }

            // Determine redirect URLs
            $redirect_url = $this->get_fallback_redirect_url($this->redirect_page);
            $redirect_fail_url = $this->get_fallback_redirect_url($this->redirect_fail_page);
            $redirect_new_url = $redirect_fail_url;

            try {
                $order = wc_get_order($order_id);
                if (!$order) {
                    wp_redirect($redirect_fail_url);
                    exit;
                }

                // Save transaction ID
                $order->set_transaction_id(sanitize_text_field($_REQUEST['easepayid']));
                $order->save();

                $status    = sanitize_text_field($_REQUEST['status']);
                $hash      = sanitize_text_field($_REQUEST['hash']);
                $checkhash = $this->compute_reverse_hash($_REQUEST);

                $trans_authorised = false;

                if ($order->get_status() === 'completed') {
                    $redirect_new_url = $redirect_url;
                } elseif (hash_equals($checkhash, $hash)) {
                    $status = strtolower($status);

                    switch ($status) {
                        case 'success':
                            $trans_authorised = true;
                            $this->msg['message'] = __('Thank you for shopping with us. Your transaction is successful.', 'woo_payeasebuzz');
                            $this->msg['class'] = 'success';

                            if ($order->get_status() !== 'processing') {
                                $order->payment_complete();
                            }
                            $order->add_order_note($this->format_order_note('Easebuzz payment successful.', $_REQUEST));
                            WC()->cart->empty_cart();
                            $this->redirectUser($order);
                            return;

                        case 'pending':
                            $trans_authorised = true;
                            $this->msg['message'] = __('Thank you for shopping with us. Right now your payment status is pending.', 'woo_payeasebuzz');
                            $this->msg['class'] = 'success';
                            $order->add_order_note($this->format_order_note('Easebuzz payment status is pending.', $_REQUEST));
                            $order->update_status('pending');
                            WC()->cart->empty_cart();
                            $redirect_new_url = $redirect_url;
                            break;

                        case 'usercancelled':
                            $trans_authorised = true;
                            $this->msg['message'] = __('You have cancelled the transaction.', 'woo_payeasebuzz');
                            $this->msg['class'] = 'error';
                            $order->add_order_note($this->format_order_note('Easebuzz payment user cancelled.', $_REQUEST));
                            $order->update_status('cancelled');
                            $redirect_new_url = $redirect_fail_url;
                            break;

                        default:
                            $this->msg['message'] = __('Oops, the transaction has failed. Please try again.', 'woo_payeasebuzz');
                            $this->msg['class'] = 'error';
                            $order->add_order_note($this->format_order_note('Transaction Status: ' . $status, $_REQUEST));
                            $redirect_new_url = $redirect_fail_url;
                            break;
                    }
                } else {
                    // Hash mismatch
                    $this->msg['message'] = __('Something Went Wrong.', 'woo_payeasebuzz');
                    $this->msg['class'] = 'error';
                    $order->add_order_note('Checksum ERROR: ' . wp_json_encode(array_map('sanitize_text_field', $_REQUEST)));
                    $redirect_new_url = $redirect_fail_url;
                }

                if (!$trans_authorised) {
                    $order->update_status('failed');
                }

                // Add WC notice
                if (function_exists('wc_add_notice') && !empty($this->msg['message'])) {
                    wc_add_notice($this->msg['message'], ($this->msg['class'] === 'success') ? 'success' : 'error');
                }
            } catch (Exception $e) {
                $this->log('Response handling error: ' . $e->getMessage());
            }

            wp_redirect($redirect_new_url);
            exit;
        }

        /**
         * Get redirect URL with fallback to My Account page.
         */
        private function get_fallback_redirect_url($page_id)
        {
            if (empty($page_id) || $page_id == 0) {
                return get_permalink(get_option('woocommerce_myaccount_page_id'));
            }
            return get_permalink($page_id);
        }

        /**
         * Redirect user to order received page.
         */
        public function redirectUser($order)
        {
            wp_redirect($this->get_return_url($order));
            exit;
        }

        /**
         * Log messages via WC Logger.
         */
        private function log($message)
        {
            $logger = wc_get_logger();
            $logger->error($message, array('source' => 'easebuzz'));
        }
    }

    // Register gateway with WooCommerce
    add_filter('woocommerce_payment_gateways', function ($methods) {
        $methods[] = 'WC_Easebuzz_Gateway';
        return $methods;
    });
}

/**
 * Add 'Settings' link on plugin page.
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'payeasebuzz_add_action_plugin');
function payeasebuzz_add_action_plugin($links)
{
    $settings_link = '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=payeasebuzz') . '">' . __('Settings') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * AJAX handler for iframe payment response.
 * Reads key/salt from WC settings (no hardcoding, no client-side secrets).
 */
add_action('wp_ajax_payment_response_iframe', 'easebuzz_payment_response_iframe');
add_action('wp_ajax_nopriv_payment_response_iframe', 'easebuzz_payment_response_iframe');

function easebuzz_payment_response_iframe()
{
    // Verify nonce
    if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'easebuzz_iframe_payment')) {
        wp_send_json(array('class' => 'error', 'message' => __('Security verification failed.', 'woo_payeasebuzz')));
    }

    $response = isset($_POST['response']) ? array_map('sanitize_text_field', $_POST['response']) : array();

    if (!isset($response['txnid']) || !isset($response['status'])) {
        wp_send_json(array('class' => 'error', 'message' => __('Invalid payment response.', 'woo_payeasebuzz')));
    }

    // Read key/salt from WC settings - NOT from client POST
    $settings   = get_option(EASEBUZZ_SETTINGS_KEY, array());
    $key_id     = isset($settings['key_id']) ? trim($settings['key_id']) : '';
    $key_secret = isset($settings['key_secret']) ? trim($settings['key_secret']) : '';

    if (empty($key_id) || empty($key_secret)) {
        wp_send_json(array('class' => 'error', 'message' => __('Payment gateway not configured.', 'woo_payeasebuzz')));
    }

    $order_id = absint($response['udf1'] ?? 0);
    if (!$order_id) {
        wp_send_json(array('class' => 'error', 'message' => __('Invalid order.', 'woo_payeasebuzz')));
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json(array('class' => 'error', 'message' => __('Order not found.', 'woo_payeasebuzz')));
    }

    // Compute reverse hash using shared function
    include_once EASEBUZZ_PLUGIN_DIR . 'easepay-lib.php';
    $checkhash = easebuzz_compute_reverse_hash($response, $key_secret);

    $return_response = array();
    $trans_authorised = false;

    if ($order->get_status() === 'completed') {
        wp_send_json(array('class' => 'success', 'message' => __('Order already processed.', 'woo_payeasebuzz')));
    }

    if (!isset($response['hash']) || !hash_equals($checkhash, $response['hash'])) {
        $order->add_order_note('Checksum ERROR (iframe): ' . wp_json_encode($response));
        $order->update_status('failed');
        wp_send_json(array('class' => 'error', 'message' => __('Security Error. Illegal access detected.', 'woo_payeasebuzz')));
    }

    $status = strtolower($response['status']);

    switch ($status) {
        case 'success':
            $trans_authorised = true;
            if ($order->get_status() !== 'processing') {
                $order->payment_complete();
            }
            $order->add_order_note(easebuzz_format_order_note('Easebuzz payment successful (iframe).', $response));
            WC()->cart->empty_cart();
            $return_response['class']   = 'success';
            $return_response['message'] = easebuzz_build_response_html(
                __('Thank you for shopping with us. Your transaction is successful.', 'woo_payeasebuzz'),
                $response, $order
            );
            break;

        case 'pending':
            $trans_authorised = true;
            $order->add_order_note(easebuzz_format_order_note('Easebuzz payment pending (iframe).', $response));
            $order->update_status('pending');
            WC()->cart->empty_cart();
            $return_response['class']   = 'pending';
            $return_response['message'] = easebuzz_build_response_html(
                __('Thank you for shopping with us. Right now your payment status is pending.', 'woo_payeasebuzz'),
                $response, $order
            );
            break;

        case 'usercancelled':
            $order->add_order_note(easebuzz_format_order_note('Easebuzz payment cancelled by user (iframe).', $response));
            $order->update_status('cancelled');
            $return_response['class']   = 'error';
            $return_response['message'] = easebuzz_build_response_html(
                __('You have cancelled the transaction.', 'woo_payeasebuzz'),
                $response, $order
            );
            break;

        default:
            $order->add_order_note(easebuzz_format_order_note('Easebuzz payment failed (iframe). Status: ' . $status, $response));
            $return_response['class']   = 'error';
            $return_response['message'] = easebuzz_build_response_html(
                __('Oops, your transaction has failed.', 'woo_payeasebuzz'),
                $response, $order
            );
            break;
    }

    if (!$trans_authorised) {
        $order->update_status('failed');
    }

    wp_send_json($return_response);
}

/**
 * Build HTML response table for iframe callbacks.
 * Renders transaction details + billing address matching the original plugin layout.
 */
function easebuzz_build_response_html($heading, $response, $order)
{
    $status       = esc_html($response['status'] ?? '');
    $easepayid    = esc_html($response['easepayid'] ?? '');
    $txnid        = esc_html($response['txnid'] ?? '');
    $bank_ref_num = esc_html($response['bank_ref_num'] ?? '');
    $amount       = esc_html($order->get_total());

    $billing_name    = esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
    $billing_addr1   = esc_html($order->get_billing_address_1());
    $billing_addr2   = esc_html($order->get_billing_address_2());
    $billing_city    = esc_html($order->get_billing_city() . ' ' . $order->get_billing_state());
    $billing_phone   = esc_html($order->get_billing_phone());
    $billing_email   = esc_html($order->get_billing_email());

    $html = "<strong>" . esc_html($heading) . "<br><br></strong>";

    // Transaction Details table
    $html .= "<style>
        .ebz-table, .ebz-table th, .ebz-table td {
            color: black;
            border: 1px solid #000;
            background: #ffffff;
            font-size: 20px;
            padding: 10px;
            border-collapse: collapse;
        }
    </style>";
    $html .= "<table class='ebz-table' style='width:100%'>";
    $html .= "<tr><td colspan='2'><strong>Transaction Details:</strong></td></tr>";
    $html .= "<tr><td>Transaction status : </td><td>{$status}</td></tr>";
    $html .= "<tr><td>Easebuzz ID : </td><td>{$easepayid}</td></tr>";
    $html .= "<tr><td>Txn id : </td><td>{$txnid}</td></tr>";

    if (!empty($bank_ref_num)) {
        $html .= "<tr><td>Bank Ref Number : </td><td>{$bank_ref_num}</td></tr>";
    }

    $html .= "<tr><td>Total Amount : </td><td>{$amount}</td></tr>";
    $html .= "</table>";

    // Billing Address table
    $html .= "<table class='ebz-table' style='width:100%'>";
    $html .= "<tr><td colspan='2'><br><strong>Billing Address</strong></td></tr>";
    $html .= "<tr><td>{$billing_name}</td></tr>";
    $html .= "<tr><td>{$billing_addr1}</td></tr>";
    $html .= "<tr><td>{$billing_addr2}</td></tr>";
    $html .= "<tr><td>{$billing_city}</td></tr>";
    $html .= "<tr><td>&#128222; {$billing_phone}</td></tr>";
    $html .= "<tr><td>{$billing_email}</td></tr>";
    $html .= "</table>";

    return $html;
}
