/**
 * Easebuzz Gateway - WooCommerce Blocks (Cart & Checkout) integration.
 *
 * Registers the Easebuzz payment method with the block-based checkout so the
 * gateway appears alongside the block Cart/Checkout and the store no longer
 * shows the "may not be compatible with the Cart block" notice.
 *
 * This gateway uses a redirect flow: on the block checkout, WooCommerce places
 * the order via the Store API and then follows the redirect returned by the
 * server-side process_payment(). No on-page card fields are required.
 */
(function () {
    const settings = window.wc.wcSettings.getSetting('payeasebuzz_data', {});
    const label =
        (settings && settings.title) ||
        window.wp.i18n.__('Easebuzz Payment Gateway', 'woo_payeasebuzz');
    const { createElement } = window.wp.element;
    const { decodeEntities } = window.wp.htmlEntities;

    /**
     * Description/content shown when the method is selected.
     */
    const Content = () => {
        return decodeEntities(settings.description || '');
    };

    /**
     * Label shown in the payment methods list.
     */
    const Label = (props) => {
        const { PaymentMethodLabel } = props.components;
        return createElement(PaymentMethodLabel, { text: decodeEntities(label) });
    };

    const Easebuzz = {
        name: 'payeasebuzz',
        label: createElement(Label),
        content: createElement(Content),
        edit: createElement(Content),
        canMakePayment: () => true,
        ariaLabel: decodeEntities(label),
        supports: {
            features: (settings && settings.supports) || ['products'],
        },
    };

    window.wc.wcBlocksRegistry.registerPaymentMethod(Easebuzz);
})();
