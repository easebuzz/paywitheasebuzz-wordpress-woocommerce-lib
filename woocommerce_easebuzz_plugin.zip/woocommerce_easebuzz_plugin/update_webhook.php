<?php

/**
 * Easebuzz Webhook Handler
 *
 * Handles asynchronous payment status updates from Easebuzz.
 * Reads merchant salt from WooCommerce settings (no hardcoding required).
 */

// Load WordPress environment
$wp_load_path = dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';
if (!file_exists($wp_load_path)) {
    easebuzz_webhook_response(500, 'WordPress environment not found.');
}
require_once $wp_load_path;

// Load shared library
require_once dirname(__FILE__) . '/easepay-lib.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    easebuzz_webhook_response(405, 'Method Not Allowed. Only POST requests are allowed.');
}

try {
    // Read salt from WooCommerce gateway settings (no hardcoding!)
    $settings = get_option(EASEBUZZ_SETTINGS_KEY, array());
    $SALT = isset($settings['key_secret']) ? trim($settings['key_secret']) : '';

    if (empty($SALT)) {
        easebuzz_webhook_response(500, 'Gateway not configured. Salt not found in settings.');
    }

    // Parse incoming webhook data
    $body = file_get_contents('php://input');
    parse_str(urldecode($body), $payload);

    if (empty($payload) || !isset($payload['txnid'])) {
        easebuzz_webhook_response(400, 'Invalid payload.');
    }

    // Verify hash integrity
    if (empty($payload['hash']) || !hash_equals(easebuzz_compute_reverse_hash($payload, $SALT), $payload['hash'])) {
        easebuzz_webhook_response(400, 'Hash verification failed.');
    }

    // Extract and validate order
    $order_id = absint($payload['udf1'] ?? 0);
    if (!$order_id) {
        easebuzz_webhook_response(400, 'Invalid order ID.');
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        easebuzz_webhook_response(400, 'Order not found for ID: ' . $order_id);
    }

    $current_status = $order->get_status();
    $payment_status = strtolower(sanitize_text_field($payload['status']));

    // Only process if order is in an updatable state
    if (in_array($current_status, array('processing', 'completed'), true)) {
        easebuzz_webhook_response(200, 'Order already processed.');
    } elseif (!in_array($current_status, array('failed', 'pending', 'cancelled', 'on-hold'), true)) {
        easebuzz_webhook_response(200, 'Order status is already updated.');
    }

    // Map Easebuzz status to WC status
    switch ($payment_status) {
        case 'success':
            $order->payment_complete(sanitize_text_field($payload['easepayid'] ?? ''));
            break;
        case 'usercancelled':
            $order->update_status('cancelled', __('Payment cancelled by user (webhook).', 'woo_payeasebuzz'));
            break;
        default:
            $order->update_status('failed', __('Payment failed (webhook).', 'woo_payeasebuzz'));
            break;
    }

    // Add order note with transaction details
    $note = easebuzz_format_order_note('Easebuzz Webhook: ' . sanitize_text_field($payload['status']), $payload);
    $order->add_order_note($note);
    $order->add_order_note("Order Status Updated via Webhook");
    easebuzz_webhook_response(200, 'Order status updated from webhook.');

} catch (Exception $e) {
    // Log the actual error for debugging, but never expose it to the client
    if (function_exists('wc_get_logger')) {
        wc_get_logger()->error('Webhook error: ' . $e->getMessage(), array('source' => 'easebuzz'));
    }
    easebuzz_webhook_response(500, 'An internal error occurred while processing the webhook.');
}

/**
 * Send webhook response and terminate execution.
 *
 * @param int    $code    HTTP status code.
 * @param string $message Response message.
 */
function easebuzz_webhook_response($code, $message)
{
    http_response_code($code);
    $prefix = ($code >= 400) ? 'Error: ' : '';
    echo $prefix . esc_html($message);
    exit;
}
